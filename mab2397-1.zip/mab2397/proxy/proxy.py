# !/usr/bin/env python
import sys, socket, thread, threading, select, time, re
class proxy:
	#Basically sets all relevant variables to become properties of the Proxy.
	#Makes it much easier to work with because otherwise I would have had to 
	#Pass a lot of variables through each function (easy to confuse, hard to alter).
	def __init__ (self,log_path,alpha,listen_port,fake_ip,web_server,browser):
		self.user,__=browser.accept()
		self.MAX_DATA=4096 #The most efficient Number according to the internet
		self.alpha=alpha
		self.listen_port=listen_port
		self.log=log_path
		self.host=str(web_server)
		self.fake_ip=fake_ip
		self.server=None #Is defined later
		self.begin=time.time()#Used to calc duration
		self.end=time.time()#Used to calc duration
		self.flag=False

		self.chunk_name=None
		self.last_chunk_name=None
		self.throughput=10 #Wasn't sure if we were supposed to initialize throughput as smallest value or largest
		self.content_len = 0
		
		self.bitrate = [10,100,500,1000] #Is updated later, just defined here for convenience
		self.curr_bitrate = self.bitrate[0]

	#FN START takes the browser's intiail request and processes it.
	#It finds the header of the first line of the request and checks it against 
	#common headers (post,get,...)
	def start(self):
		#print "starting.."
		usr_req=self.user.recv(self.MAX_DATA)
		if not usr_req:
			usr_req=None
		first_line=str(usr_req).split("\n")[0]
		req_method=first_line.split()[0]
		#There must be some data transfer and the head of it must be a recognized method
		#http://www.restapitutorial.com/lessons/httpmethods.html
		if usr_req and req_method in ['POST','GET','PUT','PATCH','DELETE','HAVE']:
			self.myLoop(usr_req)
		else:
			print "Your request did not match a known header... \n exiting now... \n"
			print req_method
			self.user.close()
			#self.server.close()
			sys.exit(1)
	
	#Creates the server socket
	def handle_Server(self,request):
		#print "handling server..."
		if ':' in self.host:
			servAddr=(self.host.split(':')[0],int(self.host.split(':')[1]))
		else:
			servAddr=(self.host,int(80))

		(family, _, _, _, address) = socket.getaddrinfo(str(servAddr[0]), servAddr[1])[0]
		self.server = socket.socket(family)
		self.server.bind((self.fake_ip,0))
		self.server.connect(address)
		self.server.send(request)

	#The part of my code that "loops" 
	#It checks if either the user socket or the client socket have recieved new data
	#IF they have, it executes the corresponding functions
	def myLoop(self,request):
		#print "entering myLoop..."
		self.handle_Server(request)
		mySockets = [self.user, self.server]
		while True: #break statement further down should pop us out of this loop
			canRead, __, excCond = select.select(mySockets, [], mySockets, 3)

			if excCond:
				print "An Exceptional Condition has occured \n"
				break

			for sock in canRead:
				data=sock.recv(self.MAX_DATA)
				if not data:
					break
				elif sock is self.user: #request from browser
					self.browserRequest(data)
				elif sock is self.server: #reply from Server
					self.serverReply(data)
				else:
					print "error"
					break

		self.user.close()
		self.server.close()

	#Finds the manifest file
	def findManifest(self,data):
		#print "finding manifest"
		if ".f4m" in str(data):
			self.begin=time.time()
			return True
		else:
			return False
	
	#Gotbitrate is a MatchObject (similar to a boolean with value true)
	#the .group(0) fn gives me the part of it that matches my search
	def findBitrate(self,data):
		#print "finding bitrate"
		if 'Frag' in str(data):
			bitrate_pattern=re.compile('/vod/\d*Seg\d*-Frag\d*')
			gotbitrate=bitrate_pattern.search(str(data))
			matches=gotbitrate.group(0)
			return gotbitrate,matches
		else:
			return False,None
	
	#Calculates the best bitrate to use based on your throughput
	def calcBitrate(self,match,data):
		#"print calculating bitrate"
		brate = match[match.find('/', 1) + 1:match.find('Seg')]#holds bitrate
		self.chunk_name = match[match.find('/'):]
		self.curr_bitrate = self.bitrate[0]
		
		for i in range(1, len(self.bitrate)):
			if self.bitrate[i] < (self.throughput / 1.5):
				self.curr_bitrate = self.bitrate[i]

		data = data.replace('/vod/' + str(brate) + 'Seg', '/vod/' + str(self.curr_bitrate) + 'Seg')
		self.chunk_name = self.chunk_name.replace('/vod/' + str(brate) + 'Seg', '/vod/' + str(self.curr_bitrate) + 'Seg')
	
	#Handles client proxy relations
	def browserRequest(self,data):
		#print "browser request"
		try:
			self.flag=self.findManifest(data)		
			check,match=self.findBitrate(data)
			if check:
				self.calcBitrate(match,data) #calculates bitrate, stores it as attribute
			self.server.send(data)
		except KeyboardInterrupt:
			print "User has requested to exit the program... \n exiting..."
			self.user.close()
			self.server.close()
			sys.exit(0)
	
	#prints to our output log
	def outputLog(self):
		#print "outputting"
		self.end = time.time()
		duration = self.end - self.begin
		
		tput = (0.008*self.content_len) / (duration) #.008 Kb/byte tput is in Kbps
		self.throughput=self.alpha*tput +(1-self.alpha)*self.throughput
		#Only want to print if the chunk is valid AND if its a new chunk
		if (self.chunk_name is not None) and (self.chunk_name is not self.last_chunk_name):
			self.last_chunk_name=self.chunk_name
			curr_log="%.2f"%self.end+" %.4f"%duration +" %.4f"%tput+" %.4f"%self.throughput+" %.2f "%self.curr_bitrate+str(self.host)+" "+self.chunk_name
			open(self.log,'a').write(curr_log + '\r\n')
		self.begin = time.time()
	#Finds all possible bitrates
	
	
	def getBitRate(self,data):
		#print "getting bitrate"
		if self.flag and 'bitrate' in str(data):
			self.bitrate = re.findall('bitrate="\d*"', str(data))
			for i in range(len(self.bitrate)):
				self.bitrate[i] = int(re.findall('\d*', str(self.bitrate[i]))[-3])
			self.flag = False


	#Finds length of chunk
	def getContentLen(self,data):
		#print "getting content length"
		if "Content-Length" in str(data):
			myString = re.search(re.compile("Content-Length:\s*\d*"), str(data))
			self.content_len = float(myString.group(0)[len("Content-Length:"):])
	
	#Handles server proxy relations
	def serverReply(self,data):
		#print "server reply"
		try:
			# when received bitrate from server, find possible bitrate
			self.getBitRate(data)
			self.getContentLen(data)

			if len(data) < self.MAX_DATA: #Chunk has finished being processed
				self.outputLog()
	
			self.user.send(data)
	
		except KeyboardInterrupt:
			#print "User has requested to exit the program... \n exiting..."
			self.user.close()
			self.server.close()
			sys.exit(0)

#Executes right at the start
#Basically the equivalent of a java "public static void main"
if __name__=='__main__':
	BACKLOG=5 #Number of connections which can be queued up. Typically somewhere between 1 and 5
	try:
		log=sys.argv[1]
		alpha=float(sys.argv[2])
		listen_port=int(sys.argv[3])
		fake_ip=sys.argv[4]
		web_server_ip=sys.argv[5]
	except Exception, e:
		print "Not enough arguments"
		sys.exit(0)
	browser=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
	browser.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
	port=listen_port
	browser.bind(('',port))
	browser.listen(BACKLOG)
	file=open(log,'w+')
	file.write("")
	file.close()
	while 1:
		try:
			myP=proxy(log_path=log,alpha=alpha,listen_port=port,fake_ip=fake_ip,web_server=web_server_ip,browser=browser)
			thread.start_new_thread(myP.start,())
			port+=1 #so any new connections will connect to a valid port
		except Exception, e:
			print "Something went wrong during startup"
			print e
			sys.exit(1)
